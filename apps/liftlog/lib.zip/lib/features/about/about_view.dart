import 'package:flutter/material.dart';
import 'package:mvvm_annotations/mvvm_annotations.dart' as mvvm;
import 'package:mvvm_flutter/mvvm_flutter.dart';
import 'package:mvvm_navigation_flutter/mvvm_navigation_flutter.dart';

part 'about_view.g.dart';

@mvvm.ViewState()
class AboutState with _$AboutStateMixin {
  final String appName;
  final String appVersion;

  const AboutState({this.appName = 'Lift Log', this.appVersion = '0.1.0'});
}

@mvvm.ViewModel()
class AboutViewModel extends MVVMViewModel<AboutState> {
  AboutViewModel() {
    emitNewState(const AboutState());
  }
}

@mvvm.View(route: '/about', deepLink: '/about')
class AboutView extends MVVMView<AboutViewModel, AboutState> {
  const AboutView({super.key});

  @override
  Widget buildWithState(
    BuildContext context,
    AboutState? oldState,
    AboutState state,
  ) {
    return Scaffold(
      appBar: AppBar(title: const Text('About')),
      body: Center(
        child: Text('${state.appName} - ${state.appVersion} placeholder'),
      ),
    );
  }
}
